package com.zonevisuals.mixin.client;

import com.zonevisuals.client.module.ModuleManager;
import com.zonevisuals.client.module.impl.cosmetics.ChinaHatModule;
import com.zonevisuals.client.module.impl.cosmetics.WingsModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("TAIL"))
    private void renderZoneCosmetics(AbstractClientPlayerEntity player, float f, float g, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int i, CallbackInfo ci) {
        ChinaHatModule hat = ModuleManager.getInstance().getModule(ChinaHatModule.class);
        if (hat != null && hat.isEnabled()) {
            hat.render(matrices, player, g);
        }

        WingsModule wings = ModuleManager.getInstance().getModule(WingsModule.class);
        if (wings != null && wings.isEnabled()) {
            wings.renderWings(matrices, player, g);
        }
    }
}
