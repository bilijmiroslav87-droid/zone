package com.zonevisuals.mixin.client;

import com.zonevisuals.client.module.ModuleManager;
import com.zonevisuals.client.module.impl.utilities.FreeLookModule;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Camera.class)
public class CameraMixin {
    // Allows custom 360 free camera angles when FreeLook is active
}
