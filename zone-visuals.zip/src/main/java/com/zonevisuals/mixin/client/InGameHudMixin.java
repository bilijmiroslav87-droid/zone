package com.zonevisuals.mixin.client;

import com.zonevisuals.client.hud.HUDManager;
import com.zonevisuals.client.module.ModuleManager;
import com.zonevisuals.client.module.impl.ui.HUDModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void renderZoneVisualsHud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        HUDModule hud = ModuleManager.getInstance().getModule(HUDModule.class);
        if (hud != null && hud.isEnabled()) {
            HUDManager.getInstance().renderAll(context, tickCounter.getTickDelta(true));
        }
    }
}
