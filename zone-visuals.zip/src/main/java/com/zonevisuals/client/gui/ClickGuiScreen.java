package com.zonevisuals.client.gui;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.ModuleManager;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.ModeSetting;
import com.zonevisuals.client.module.setting.NumberSetting;
import com.zonevisuals.client.module.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private int x = 60;
    private int y = 40;
    private int width = 450;
    private int height = 280;
    private Category currentCategory = Category.COSMETICS;
    private String searchQuery = "";

    public ClickGuiScreen() {
        super(Text.literal("Zone Visuals ClickGUI"));
    }

    @Override
    protected void init() {
        super.init();
        this.width = Math.min(480, this.client.getWindow().getScaledWidth() - 40);
        this.height = Math.min(290, this.client.getWindow().getScaledHeight() - 40);
        this.x = (this.client.getWindow().getScaledWidth() - this.width) / 2;
        this.y = (this.client.getWindow().getScaledHeight() - this.height) / 2;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark blurred modal window
        context.fill(x, y, x + width, y + height, new Color(13, 10, 19, 240).getRGB());
        context.drawBorder(x, y, width, height, new Color(147, 51, 234, 180).getRGB());

        // Top bar
        context.fill(x, y, x + width, y + 32, new Color(20, 15, 30, 240).getRGB());
        context.drawText(this.textRenderer, "§d§lZONE §fVISUALS §7• Client v1.0.0", x + 12, y + 11, 0xFFFFFF, false);

        // Sidebar categories
        int sideW = 110;
        context.fill(x, y + 32, x + sideW, y + height, new Color(17, 13, 25, 240).getRGB());
        context.fill(x + sideW - 1, y + 32, x + sideW, y + height, new Color(48, 34, 66).getRGB());

        int catY = y + 42;
        for (Category cat : Category.values()) {
            boolean active = cat == currentCategory;
            if (active) {
                context.fill(x + 6, catY - 2, x + sideW - 6, catY + 16, new Color(147, 51, 234, 120).getRGB());
                context.fill(x + 6, catY - 2, x + 8, catY + 16, new Color(192, 132, 252).getRGB());
            }
            context.drawText(this.textRenderer, (active ? "§f§l" : "§7") + cat.getDisplayName(), x + 14, catY + 2, 0xFFFFFF, false);
            catY += 24;
        }

        // Module cards area
        int modX = x + sideW + 12;
        int modY = y + 42;
        List<Module> mods = ModuleManager.getInstance().getModulesByCategory(currentCategory);

        for (Module m : mods) {
            boolean enabled = m.isEnabled();
            int cardW = width - sideW - 24;
            int cardH = 26;

            // Module card background
            context.fill(modX, modY, modX + cardW, modY + cardH, enabled ? new Color(35, 20, 52, 230).getRGB() : new Color(20, 16, 28, 200).getRGB());
            context.drawBorder(modX, modY, cardW, cardH, enabled ? new Color(168, 85, 247, 180).getRGB() : new Color(42, 32, 56, 120).getRGB());

            // Module title
            context.drawText(this.textRenderer, (enabled ? "§d§l" : "§f") + m.getName(), modX + 8, modY + 5, 0xFFFFFF, false);
            context.drawText(this.textRenderer, "§8" + m.getDescription(), modX + 8, modY + 15, 0x888888, false);

            // Toggle switch on the right
            int swX = modX + cardW - 32;
            int swY = modY + 7;
            context.fill(swX, swY, swX + 24, swY + 12, enabled ? new Color(168, 85, 247).getRGB() : new Color(48, 38, 64).getRGB());
            int knobX = enabled ? swX + 13 : swX + 2;
            context.fill(knobX, swY + 2, knobX + 8, swY + 10, 0xFFFFFF);

            modY += 30;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int sideW = 110;
        // Check Category clicks
        int catY = y + 42;
        for (Category cat : Category.values()) {
            if (mouseX >= x && mouseX <= x + sideW && mouseY >= catY - 2 && mouseY <= catY + 18) {
                currentCategory = cat;
                return true;
            }
            catY += 24;
        }

        // Check Module toggles
        int modX = x + sideW + 12;
        int modY = y + 42;
        int cardW = width - sideW - 24;
        List<Module> mods = ModuleManager.getInstance().getModulesByCategory(currentCategory);

        for (Module m : mods) {
            if (mouseX >= modX && mouseX <= modX + cardW && mouseY >= modY && mouseY <= modY + 26) {
                m.toggle();
                return true;
            }
            modY += 30;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
