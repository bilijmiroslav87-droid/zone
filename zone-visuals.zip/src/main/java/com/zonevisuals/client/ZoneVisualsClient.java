package com.zonevisuals.client;

import com.zonevisuals.client.hud.HUDManager;
import com.zonevisuals.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZoneVisualsClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("ZoneVisuals");

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Zone Visuals] Initializing modules and HUD manager...");
        ModuleManager.getInstance().init();
        HUDManager.getInstance().init();
        LOGGER.info("[Zone Visuals] Successfully loaded for Minecraft 1.21.4!");
    }
}
