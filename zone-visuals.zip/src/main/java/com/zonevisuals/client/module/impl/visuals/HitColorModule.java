package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.ColorSetting;

import java.awt.Color;

public class HitColorModule extends Module {
    public final ColorSetting hitColor = new ColorSetting("Damage Tint", new Color(168, 85, 247, 160));

    public HitColorModule() {
        super("Hit Color", Category.VISUALS, "Replaces red hurt tint on entities with your custom aesthetic color");
        addSettings(hitColor);
    }
}
