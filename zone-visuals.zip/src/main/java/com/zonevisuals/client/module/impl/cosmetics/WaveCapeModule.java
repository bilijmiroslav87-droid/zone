package com.zonevisuals.client.module.impl.cosmetics;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.NumberSetting;

import java.awt.Color;

public class WaveCapeModule extends Module {
    public final NumberSetting waveSpeed = new NumberSetting("Wave Speed", 0.5, 3.0, 1.4, 0.1);
    public final NumberSetting waveIntensity = new NumberSetting("Intensity", 0.1, 1.5, 0.8, 0.1);
    public final BooleanSetting smoothPhysics = new BooleanSetting("Smooth Physics", true);
    public final ColorSetting capeColor = new ColorSetting("Gradient Color", new Color(147, 51, 234));

    public WaveCapeModule() {
        super("Wave Cape", Category.COSMETICS, "Adds fluid wavy physics and gradient rendering to custom player capes");
        addSettings(waveSpeed, waveIntensity, smoothPhysics, capeColor);
    }
}
