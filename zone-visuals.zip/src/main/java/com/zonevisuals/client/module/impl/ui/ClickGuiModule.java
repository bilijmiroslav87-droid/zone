package com.zonevisuals.client.module.impl.ui;

import com.zonevisuals.client.gui.ClickGuiScreen;
import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("Click GUI", Category.UI, "Opens the interactive Zone Visuals modern graphical user interface");
        setKeybind(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen == null) {
            mc.setScreen(new ClickGuiScreen());
        }
        setEnabled(false);
    }
}
