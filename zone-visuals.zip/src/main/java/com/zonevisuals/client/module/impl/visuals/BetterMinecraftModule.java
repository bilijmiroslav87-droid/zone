package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;

public class BetterMinecraftModule extends Module {
    public final BooleanSetting smoothCamera = new BooleanSetting("Smooth Camera", true);
    public final BooleanSetting fastFog = new BooleanSetting("Clear Water & Fog", true);

    public BetterMinecraftModule() {
        super("Better Minecraft", Category.VISUALS, "Improves overall graphics, removes fog and smooths client camera");
        addSettings(smoothCamera, fastFog);
    }
}
