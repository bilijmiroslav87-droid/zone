package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.NumberSetting;

public class MotionBlurModule extends Module {
    public final NumberSetting blurAmount = new NumberSetting("Strength", 1.0, 10.0, 4.0, 0.5);

    public MotionBlurModule() {
        super("Motion Blur", Category.VISUALS, "Adds a cinematic motion blur effect when turning your camera");
        addSettings(blurAmount);
    }
}
