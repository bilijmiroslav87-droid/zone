package com.zonevisuals.client.module;

public enum Category {
    COSMETICS("Cosmetics"),
    VISUALS("Visuals"),
    UI("HUD & UI"),
    UTILITIES("Utilities");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
