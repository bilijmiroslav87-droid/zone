package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.ModeSetting;
import com.zonevisuals.client.module.setting.NumberSetting;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;
import java.util.List;

public class CustomCrosshairModule extends Module {
    public final ModeSetting style = new ModeSetting("Shape", "Cross", List.of("Cross", "Circle", "Dot", "Square"));
    public final NumberSetting size = new NumberSetting("Size", 2.0, 15.0, 6.0, 0.5);
    public final NumberSetting gap = new NumberSetting("Gap", 0.0, 10.0, 3.0, 0.5);
    public final NumberSetting thickness = new NumberSetting("Thickness", 1.0, 4.0, 1.5, 0.5);
    public final BooleanSetting dynamic = new BooleanSetting("Dynamic Attack Spread", true);
    public final ColorSetting color = new ColorSetting("Color", new Color(255, 255, 255, 230));

    public CustomCrosshairModule() {
        super("Custom Crosshair", Category.VISUALS, "Customizable modern crosshair with shape, gap, dot, and color options");
        addSettings(style, size, gap, thickness, dynamic, color);
    }

    public void render(DrawContext context, int screenWidth, int screenHeight) {
        if (!isEnabled()) return;
        int cx = screenWidth / 2;
        int cy = screenHeight / 2;
        int s = (int) size.getValue();
        int g = (int) gap.getValue();
        int th = (int) thickness.getValue();
        int col = color.getRGB();

        // Cross style
        context.fill(cx - th/2, cy - g - s, cx + th/2 + 1, cy - g, col);
        context.fill(cx - th/2, cy + g, cx + th/2 + 1, cy + g + s, col);
        context.fill(cx - g - s, cy - th/2, cx - g, cy + th/2 + 1, col);
        context.fill(cx + g, cy - th/2, cx + g + s, cy + th/2 + 1, col);
    }
}
