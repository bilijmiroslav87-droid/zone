package com.zonevisuals.client.module.impl.ui;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;

import java.awt.Color;

public class HUDModule extends Module {
    public final BooleanSetting watermark = new BooleanSetting("Watermark", true);
    public final BooleanSetting arrayList = new BooleanSetting("Active List", true);
    public final BooleanSetting sessionInfo = new BooleanSetting("Session Widget", true);
    public final BooleanSetting cps = new BooleanSetting("CPS Counter", true);
    public final ColorSetting primaryColor = new ColorSetting("Theme Color", new Color(168, 85, 247));

    public HUDModule() {
        super("HUD Overlay", Category.UI, "Configures Zone Visuals HUD, watermark, array list and statistics");
        addSettings(watermark, arrayList, sessionInfo, cps, primaryColor);
        setEnabled(true);
    }
}
