package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;

public class ItemPhysicModule extends Module {
    public ItemPhysicModule() {
        super("Item Physics", Category.VISUALS, "Makes dropped items lay realistically flat on ground with 3D rotation");
    }
}
