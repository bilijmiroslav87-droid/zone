package com.zonevisuals.client.module.impl.cosmetics;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.NumberSetting;

import java.awt.Color;

public class JumpCircleModule extends Module {
    public final NumberSetting maxRadius = new NumberSetting("Max Radius", 1.0, 4.0, 2.2, 0.2);
    public final NumberSetting duration = new NumberSetting("Duration", 10, 50, 24, 2);
    public final ColorSetting circleColor = new ColorSetting("Color", new Color(168, 85, 247, 200));

    public JumpCircleModule() {
        super("Jump Circle", Category.COSMETICS, "Draws an expanding smooth neon ripple circle on the ground when you jump");
        addSettings(maxRadius, duration, circleColor);
    }
}
