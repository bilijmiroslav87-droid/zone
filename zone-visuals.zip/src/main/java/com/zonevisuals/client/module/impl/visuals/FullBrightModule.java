package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.NumberSetting;

public class FullBrightModule extends Module {
    public final NumberSetting gamma = new NumberSetting("Brightness", 1.0, 15.0, 10.0, 1.0);

    public FullBrightModule() {
        super("FullBright", Category.VISUALS, "Increases in-game brightness so caves and nighttime are clearly visible");
        addSettings(gamma);
    }
}
