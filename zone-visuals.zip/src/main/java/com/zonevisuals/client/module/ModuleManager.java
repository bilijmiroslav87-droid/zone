package com.zonevisuals.client.module;

import com.zonevisuals.client.module.impl.cosmetics.*;
import com.zonevisuals.client.module.impl.ui.*;
import com.zonevisuals.client.module.impl.utilities.*;
import com.zonevisuals.client.module.impl.visuals.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final ModuleManager INSTANCE = new ModuleManager();
    private final List<Module> modules = new ArrayList<>();

    public static ModuleManager getInstance() {
        return INSTANCE;
    }

    public void init() {
        // Cosmetics
        register(new ChinaHatModule());
        register(new WingsModule());
        register(new WaveCapeModule());
        register(new TrailsModule());
        register(new JumpCircleModule());

        // Visuals
        register(new CustomCrosshairModule());
        register(new FullBrightModule());
        register(new MotionBlurModule());
        register(new HitColorModule());
        register(new BlockOverlayModule());
        register(new ItemPhysicModule());
        register(new BetterMinecraftModule());

        // UI
        register(new HUDModule());
        register(new ClickGuiModule());

        // Utilities
        register(new SprintModule());
        register(new FreeLookModule());
        register(new NoRenderModule());
    }

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) list.add(m);
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module m : modules) {
            if (clazz.isInstance(m)) return (T) m;
        }
        return null;
    }
}
