package com.zonevisuals.client.module.impl.utilities;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class SprintModule extends Module {
    public SprintModule() {
        super("Auto Sprint", Category.UTILITIES, "Automatically keeps your player sprinting while moving forward");
        setEnabled(true);
    }

    public void onTick() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.forwardSpeed > 0 && !mc.player.isSneaking() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
