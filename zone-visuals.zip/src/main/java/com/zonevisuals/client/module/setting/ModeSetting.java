package com.zonevisuals.client.module.setting;

import java.util.List;

public class ModeSetting extends Setting<String> {
    private final List<String> modes;
    private int index;

    public ModeSetting(String name, String defaultMode, List<String> modes) {
        super(name, defaultMode);
        this.modes = modes;
        this.index = Math.max(0, modes.indexOf(defaultMode));
    }

    public List<String> getModes() { return modes; }

    public void cycle() {
        index = (index + 1) % modes.size();
        setValue(modes.get(index));
    }
}
