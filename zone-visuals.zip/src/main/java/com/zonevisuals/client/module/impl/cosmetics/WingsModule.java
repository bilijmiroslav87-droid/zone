package com.zonevisuals.client.module.impl.cosmetics;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.ModeSetting;
import com.zonevisuals.client.module.setting.NumberSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.awt.Color;
import java.util.List;

public class WingsModule extends Module {
    public final ModeSetting type = new ModeSetting("Style", "Dragon", List.of("Dragon", "Angel", "Butterfly"));
    public final NumberSetting scale = new NumberSetting("Scale", 0.5, 2.0, 1.0, 0.1);
    public final NumberSetting flapSpeed = new NumberSetting("Flap Speed", 0.5, 3.0, 1.2, 0.1);
    public final BooleanSetting chroma = new BooleanSetting("Chroma", true);
    public final ColorSetting wingColor = new ColorSetting("Wing Color", new Color(168, 85, 247, 210));

    public WingsModule() {
        super("Wings", Category.COSMETICS, "Custom animated dragon and angel wings attached to player back");
        addSettings(type, scale, flapSpeed, chroma, wingColor);
    }

    public void renderWings(MatrixStack matrices, PlayerEntity player, float tickDelta) {
        if (!isEnabled()) return;

        matrices.push();
        float s = (float) scale.getValue();
        matrices.scale(s, s, s);
        matrices.translate(0.0, 0.35, 0.15);

        float speed = (float) flapSpeed.getValue();
        float wave = MathHelper.sin((player.age + tickDelta) * 0.15f * speed);
        float wingAngle = wave * 28.0f;

        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(wingAngle));
        matrices.pop();
    }
}
