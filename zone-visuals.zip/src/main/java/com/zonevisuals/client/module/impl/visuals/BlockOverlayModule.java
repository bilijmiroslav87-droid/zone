package com.zonevisuals.client.module.impl.visuals;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;

import java.awt.Color;

public class BlockOverlayModule extends Module {
    public final BooleanSetting fill = new BooleanSetting("Fill Box", true);
    public final BooleanSetting outline = new BooleanSetting("Outline", true);
    public final ColorSetting color = new ColorSetting("Color", new Color(168, 85, 247, 120));

    public BlockOverlayModule() {
        super("Block Overlay", Category.VISUALS, "Highlights targeted blocks with custom outline and shaded gradient overlay");
        addSettings(fill, outline, color);
    }
}
