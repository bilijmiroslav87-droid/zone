package com.zonevisuals.client.module.setting;

import java.awt.Color;

public class ColorSetting extends Setting<Color> {
    public ColorSetting(String name, Color defaultColor) {
        super(name, defaultColor);
    }

    public int getRGB() {
        return getValue().getRGB();
    }
}
