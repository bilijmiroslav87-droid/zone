package com.zonevisuals.client.module.impl.utilities;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;

public class FreeLookModule extends Module {
    public FreeLookModule() {
        super("Free Look", Category.UTILITIES, "Enables smooth 360-degree third-person camera rotation around player");
    }
}
