package com.zonevisuals.client.module.impl.cosmetics;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.ModeSetting;
import com.zonevisuals.client.module.setting.NumberSetting;

import java.awt.Color;
import java.util.List;

public class TrailsModule extends Module {
    public final ModeSetting mode = new ModeSetting("Trail Mode", "Ribbon", List.of("Ribbon", "Stars", "Hearts", "Glow"));
    public final NumberSetting length = new NumberSetting("Trail Length", 5, 40, 18, 1);
    public final ColorSetting color = new ColorSetting("Color", new Color(192, 132, 252));

    public TrailsModule() {
        super("Trails", Category.COSMETICS, "Leaves smooth neon trails and particle ribbons behind the player");
        addSettings(mode, length, color);
    }
}
