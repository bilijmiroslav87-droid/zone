package com.zonevisuals.client.module.impl.utilities;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;

public class NoRenderModule extends Module {
    public final BooleanSetting fire = new BooleanSetting("No Fire Overlay", true);
    public final BooleanSetting pumpkin = new BooleanSetting("No Pumpkin Overlay", true);
    public final BooleanSetting hurtCam = new BooleanSetting("No Hurt Cam Shake", true);
    public final BooleanSetting blindness = new BooleanSetting("No Blindness / Darkness", true);

    public NoRenderModule() {
        super("No Render", Category.UTILITIES, "Hides annoying screen overlays like burning fire, hurt camera shake and pumpkin overlay");
        addSettings(fire, pumpkin, hurtCam, blindness);
        setEnabled(true);
    }
}
