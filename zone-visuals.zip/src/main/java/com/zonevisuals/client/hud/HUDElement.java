package com.zonevisuals.client.hud;

import net.minecraft.client.gui.DrawContext;

public abstract class HUDElement {
    private final String name;
    private int x;
    private int y;
    private int width;
    private int height;

    public HUDElement(String name, int x, int y, int width, int height) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public abstract void render(DrawContext context, float tickDelta);

    public String getName() { return name; }
    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
