package com.zonevisuals.client.hud.elements;

import com.zonevisuals.client.hud.HUDElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

public class SessionElement extends HUDElement {
    private final long startTime = System.currentTimeMillis();

    public SessionElement() {
        super("Session Info", 8, 32, 135, 42);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int x = getX();
        int y = getY();
        int w = getWidth();
        int h = getHeight();

        context.fill(x, y, x + w, y + h, new Color(15, 12, 22, 200).getRGB());
        context.fill(x, y, x + 2, y + h, new Color(192, 132, 252).getRGB());
        context.drawBorder(x, y, w, h, new Color(48, 32, 64, 160).getRGB());

        long elapsedSec = (System.currentTimeMillis() - startTime) / 1000;
        long m = elapsedSec / 60;
        long s = elapsedSec % 60;
        String timeStr = String.format("%02d:%02d", m, s);

        context.drawText(mc.textRenderer, "§d§lSESSION STATS", x + 6, y + 4, 0xFFFFFF, false);
        context.drawText(mc.textRenderer, "§7Time: §f" + timeStr, x + 6, y + 16, 0xCCCCCC, false);

        int px = (int) mc.player.getX();
        int py = (int) mc.player.getY();
        int pz = (int) mc.player.getZ();
        context.drawText(mc.textRenderer, "§7XYZ: §a" + px + " " + py + " " + pz, x + 6, y + 27, 0xCCCCCC, false);
    }
}
