package com.zonevisuals.client.hud.elements;

import com.zonevisuals.client.hud.HUDElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

public class WatermarkElement extends HUDElement {
    public WatermarkElement() {
        super("Watermark", 8, 8, 175, 18);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int x = getX();
        int y = getY();
        int w = getWidth();
        int h = getHeight();

        // Dark card background
        context.fill(x, y, x + w, y + h, new Color(15, 12, 22, 210).getRGB());
        // Left accent neon border line
        context.fill(x, y, x + 2, y + h, new Color(168, 85, 247).getRGB());
        // Subtle outline
        context.drawBorder(x, y, w, h, new Color(48, 32, 64, 180).getRGB());

        int fps = mc.getCurrentFps();
        int ping = 0;
        if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
            ping = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
        }

        String text = "§d§lZONE §fVISUALS §7| §f" + fps + " fps §7| §b" + ping + " ms";
        context.drawText(mc.textRenderer, text, x + 6, y + 5, 0xFFFFFF, false);
    }
}
