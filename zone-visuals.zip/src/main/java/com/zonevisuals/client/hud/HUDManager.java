package com.zonevisuals.client.hud;

import com.zonevisuals.client.hud.elements.*;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class HUDManager {
    private static final HUDManager INSTANCE = new HUDManager();
    private final List<HUDElement> elements = new ArrayList<>();

    public static HUDManager getInstance() {
        return INSTANCE;
    }

    public void init() {
        elements.add(new WatermarkElement());
        elements.add(new SessionElement());
        elements.add(new CPSElement());
        elements.add(new ArrayListElement());
    }

    public void renderAll(DrawContext context, float tickDelta) {
        for (HUDElement element : elements) {
            element.render(context, tickDelta);
        }
    }

    public List<HUDElement> getElements() {
        return elements;
    }
}
