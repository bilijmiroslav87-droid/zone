package com.zonevisuals.client.hud.elements;

import com.zonevisuals.client.hud.HUDElement;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;
import java.util.List;

public class ArrayListElement extends HUDElement {
    public ArrayListElement() {
        super("Active Modules List", 0, 6, 120, 0);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int screenWidth = mc.getWindow().getScaledWidth();
        int y = 6;
        int count = 0;

        List<Module> list = ModuleManager.getInstance().getModules();
        for (Module m : list) {
            if (!m.isEnabled()) continue;

            String name = m.getName();
            int strW = mc.textRenderer.getWidth(name);
            int itemW = strW + 10;
            int x = screenWidth - itemW - 4;

            // Gradient color wave
            float hue = ((System.currentTimeMillis() - count * 150L) % 3500L) / 3500.0f;
            Color waveColor = Color.getHSBColor(hue, 0.7f, 1.0f);

            // Card background
            context.fill(x, y, x + itemW, y + 13, new Color(15, 12, 22, 200).getRGB());
            // Right neon stripe
            context.fill(x + itemW - 2, y, x + itemW, y + 13, waveColor.getRGB());

            context.drawText(mc.textRenderer, name, x + 4, y + 3, waveColor.getRGB(), false);
            y += 14;
            count++;
        }
    }
}
