package com.zonevisuals.client.hud.elements;

import com.zonevisuals.client.hud.HUDElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class CPSElement extends HUDElement {
    private static final List<Long> leftClicks = new ArrayList<>();
    private static final List<Long> rightClicks = new ArrayList<>();

    public CPSElement() {
        super("CPS Counter", 8, 80, 85, 20);
    }

    public static void onLeftClick() {
        leftClicks.add(System.currentTimeMillis());
    }

    public static void onRightClick() {
        rightClicks.add(System.currentTimeMillis());
    }

    private int getCps(List<Long> clicks) {
        long now = System.currentTimeMillis();
        clicks.removeIf(t -> now - t > 1000);
        return clicks.size();
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int x = getX();
        int y = getY();
        int w = getWidth();
        int h = getHeight();

        context.fill(x, y, x + w, y + h, new Color(15, 12, 22, 200).getRGB());
        context.fill(x, y, x + 2, y + h, new Color(168, 85, 247).getRGB());
        context.drawBorder(x, y, w, h, new Color(48, 32, 64, 160).getRGB());

        int l = getCps(leftClicks);
        int r = getCps(rightClicks);
        String text = "§dCPS: §f" + l + " §7| §f" + r;
        context.drawText(mc.textRenderer, text, x + 6, y + 6, 0xFFFFFF, false);
    }
}
