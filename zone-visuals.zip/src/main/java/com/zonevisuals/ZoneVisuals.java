package com.zonevisuals;

public class ZoneVisuals {
    public static final String MOD_ID = "zonevisuals";
    public static final String MOD_NAME = "Zone Visuals";
    public static final String VERSION = "1.0.0";
}
