package com.plintusvisuals.mixin.client;

import com.plintusvisuals.client.module.ModuleManager;
import com.plintusvisuals.client.module.impl.cosmetics.ChinaHatModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderTail(AbstractClientPlayerEntity player, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        ChinaHatModule hatModule = ModuleManager.getByClass(ChinaHatModule.class);
        if (hatModule != null && hatModule.isToggled()) {
            hatModule.renderHat(matrices, player, tickDelta);
        }
    }
}
