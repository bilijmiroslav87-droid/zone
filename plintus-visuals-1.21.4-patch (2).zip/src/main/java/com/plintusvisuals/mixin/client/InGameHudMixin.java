package com.plintusvisuals.mixin.client;

import com.plintusvisuals.client.module.ModuleManager;
import com.plintusvisuals.client.module.impl.ui.CustomCrosshairModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void onRenderCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        CustomCrosshairModule crosshair = ModuleManager.getByClass(CustomCrosshairModule.class);
        if (crosshair != null && crosshair.isToggled()) {
            ci.cancel();
            crosshair.render2D(context, context.getScaledWindowWidth(), context.getScaledWindowHeight());
        }
    }
}
