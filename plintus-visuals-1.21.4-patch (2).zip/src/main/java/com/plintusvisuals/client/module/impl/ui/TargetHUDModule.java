package com.plintusvisuals.client.hud.elements;

import com.plintusvisuals.client.hud.HUDElement;
import dev.sxmurxy.mre.MinecraftRenderEnhancer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

public class TargetHUDElement extends HUDElement {
    public TargetHUDElement() {
        super("TargetHUD", 150, 45);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        // Отрисовка подложки через PillBlurBuilder
        MinecraftRenderEnhancer.getInstance()
            .getPillBlurBuilder()
            .size(getWidth(), getHeight())
            .radius(10f)
            .build();
    }
}