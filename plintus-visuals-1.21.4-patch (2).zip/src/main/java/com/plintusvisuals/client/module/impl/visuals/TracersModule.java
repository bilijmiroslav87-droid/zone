package com.plintusvisuals.client.module.impl.visuals;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.BooleanSetting;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

public class TracersModule extends Module {
    public final NumberSetting lineWidth = new NumberSetting("LineWidth", 1.5f, 0.5f, 4.0f, 0.5f);
    public final BooleanSetting playersOnly = new BooleanSetting("PlayersOnly", true);
    public final ColorSetting color = new ColorSetting("Color", new Color(56, 189, 248, 200));

    public TracersModule() {
        super("Tracers", "Линии трасеров от прицела к другим игрокам", Category.VISUALS);
        addSettings(lineWidth, playersOnly, color);
    }

    public void render3D(MatrixStack matrices, float tickDelta) {
        if (!isToggled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        Vec3d crosshair = new Vec3d(0, 0, 1)
            .rotateX(-(float) Math.toRadians(mc.gameRenderer.getCamera().getPitch()))
            .rotateY(-(float) Math.toRadians(mc.gameRenderer.getCamera().getYaw()));

        Color c = color.getColor();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        Matrix4f mat = matrices.peek().getPositionMatrix();

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;
            if (playersOnly.get() && !(entity instanceof PlayerEntity)) continue;

            Vec3d targetPos = entity.getLerpedPos(tickDelta).subtract(cameraPos);

            buffer.vertex(mat, (float) crosshair.x, (float) crosshair.y, (float) crosshair.z)
                  .color(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());

            buffer.vertex(mat, (float) targetPos.x, (float) (targetPos.y + entity.getHeight() / 2f), (float) targetPos.z)
                  .color(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.disableBlend();
    }
}