package com.plintusvisuals.client.module.impl.cosmetics;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.BooleanSetting;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

import java.awt.Color;

public class ChinaHatModule extends Module {
    public final NumberSetting radius = new NumberSetting("Radius", 0.7f, 0.3f, 1.5f, 0.05f);
    public final NumberSetting height = new NumberSetting("Height", 0.3f, 0.1f, 0.8f, 0.05f);
    public final BooleanSetting firstPerson = new BooleanSetting("FirstPerson", false);
    public final ModeSetting colorMode = new ModeSetting("ColorMode", "Gradient", "Gradient", "Rainbow", "Static");
    public final ColorSetting color = new ColorSetting("Color", new Color(56, 189, 248, 180));

    public ChinaHatModule() {
        super("ChinaHat", "Конусообразная шляпа над головой игрока", Category.COSMETICS);
        addSettings(radius, height, firstPerson, colorMode, color);
    }

    public void renderHat(MatrixStack matrices, PlayerEntity player, float tickDelta) {
        if (!isToggled()) return;

        matrices.push();
        // Позиционирование ровно над макушкой головы
        matrices.translate(0.0, player.getHeight() + 0.15, 0.0);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) (System.currentTimeMillis() % 3600L) / 10.0f));

        float r = radius.getFloatValue();
        float h = height.getFloatValue();
        Color c = color.getColor();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        Matrix4f mat = matrices.peek().getPositionMatrix();

        // Вершина конуса
        buffer.vertex(mat, 0f, h, 0f).color(c.getRed(), c.getGreen(), c.getBlue(), 230);

        // Основание конуса (36 сегментов)
        for (int i = 0; i <= 36; i++) {
            double angle = (i * (Math.PI * 2) / 36);
            float x = (float) (Math.cos(angle) * r);
            float z = (float) (Math.sin(angle) * r);
            buffer.vertex(mat, x, 0f, z).color(c.getRed(), c.getGreen(), c.getBlue(), 60);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        matrices.pop();
    }
}