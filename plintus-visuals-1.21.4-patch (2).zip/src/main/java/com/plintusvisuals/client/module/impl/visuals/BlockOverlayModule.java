package com.plintusvisuals.client.module.impl.visuals;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import dev.sxmurxy.mre.MinecraftRenderEnhancer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.awt.Color;

public class BlockOverlayModule extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Shaders", "Shaders", "Outline", "Filled", "GradientBox");
    public final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0f, 1.0f, 5.0f, 0.5f);
    public final ColorSetting color = new ColorSetting("Color", new Color(99, 102, 241, 160));

    public BlockOverlayModule() {
        super("BlockOverlay", "Красивое выделение блока под прицелом", Category.VISUALS);
        addSettings(mode, lineWidth, color);
    }

    public void renderBlock(MatrixStack matrices, BlockPos pos) {
        if (!isToggled() || pos == null) return;
        Box box = new Box(pos);
        Color c = color.getColor();

        if (mode.is("Shaders")) {
            // MRE Shader Box3D
            MinecraftRenderEnhancer.getInstance()
                .getBox3DBuilder()
                .box(box)
                .color(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha())
                .build();
        }
    }
}