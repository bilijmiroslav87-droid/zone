package com.plintusvisuals.client.module.impl.visuals;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import java.awt.Color;

public class CustomFogModule extends Module {
    public final NumberSetting distance = new NumberSetting("Distance", 12.0f, 2.0f, 48.0f, 2.0f);
    public final ColorSetting color = new ColorSetting("Color", new Color(168, 85, 247, 255));

    public CustomFogModule() {
        super("CustomFog", "Настройка цвета и дистанции тумана мира", Category.VISUALS);
        addSettings(distance, color);
    }
}