# Plintus Visuals 1.21.4 (Fold Craft Edition)

Мод для Minecraft 1.21.4 Fabric с кастомными визуалами и MRE шейдерами.

## Как скомпилировать через GitHub Actions:
1. Залейте содержимое этого архива в ваш GitHub репозиторий.
2. Вкладка **Actions** -> воркфлоу `Java CI with Gradle` запустится автоматически.
3. Скачайте готовый `.jar` файл из раздела **Artifacts** или **Releases**!

## Как запустить в Fold Craft Launcher (Android):
1. Скопируйте собранный `plintus-1.21.4.jar` в папку `/games/FoldCraftLauncher/.minecraft/mods/`.
2. Установите версию **Fabric 1.21.4**.
3. В настройках рендерера лаунчера выберите **Zink (Vulkan)** или **Holy GL4ES** для шейдеров MRE.
