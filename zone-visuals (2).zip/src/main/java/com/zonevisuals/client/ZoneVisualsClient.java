package com.zonevisuals.client;

import com.zonevisuals.client.gui.ClickGuiScreen;
import com.zonevisuals.client.hud.HUDManager;
import com.zonevisuals.client.module.ModuleManager;
import com.zonevisuals.client.module.impl.ui.HUDModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZoneVisualsClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("ZoneVisuals");
    public static KeyBinding clickGuiKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Zone Visuals] Initializing modules and HUD manager...");
        ModuleManager.getInstance().init();
        HUDManager.getInstance().init();

        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.zonevisuals.clickgui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.zonevisuals"
        ));

        // Render HUD elements safely
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            HUDModule hud = ModuleManager.getInstance().getModule(HUDModule.class);
            if (hud != null && hud.isEnabled()) {
                HUDManager.getInstance().renderAll(context, tickCounter.getTickDelta(true));
            }
        });

        // Keybind handling to open ClickGUI
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (clickGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
        });

        LOGGER.info("[Zone Visuals] Successfully loaded for Minecraft 1.21.4!");
    }
}
