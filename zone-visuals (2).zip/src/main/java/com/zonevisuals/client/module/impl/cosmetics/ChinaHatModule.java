package com.zonevisuals.client.module.impl.cosmetics;

import com.zonevisuals.client.module.Category;
import com.zonevisuals.client.module.Module;
import com.zonevisuals.client.module.setting.BooleanSetting;
import com.zonevisuals.client.module.setting.ColorSetting;
import com.zonevisuals.client.module.setting.NumberSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.awt.Color;

public class ChinaHatModule extends Module {
    public final NumberSetting radius = new NumberSetting("Radius", 0.3, 1.2, 0.65, 0.05);
    public final NumberSetting height = new NumberSetting("Height", 0.1, 0.6, 0.28, 0.02);
    public final NumberSetting yOffset = new NumberSetting("Y Offset", -0.2, 0.6, 0.12, 0.02);
    public final NumberSetting rotateSpeed = new NumberSetting("Rotate Speed", 0.5, 4.0, 1.5, 0.1);
    public final BooleanSetting rainbow = new BooleanSetting("Rainbow Mode", true);
    public final ColorSetting color = new ColorSetting("Hat Color", new Color(168, 85, 247, 180));

    public ChinaHatModule() {
        super("China Hat", Category.COSMETICS, "Glowing cone hat over the head with smooth rainbow gradients");
        addSettings(radius, height, yOffset, rotateSpeed, rainbow, color);
    }

    public void render(MatrixStack matrices, PlayerEntity player, float tickDelta) {
        if (!isEnabled()) return;

        matrices.push();
        float offset = yOffset.getFloatValue();
        matrices.translate(0.0, player.getEyeHeight(player.getPose()) + offset, 0.0);

        float speed = rotateSpeed.getFloatValue();
        float angle = ((System.currentTimeMillis() % 3600) / 10.0f) * speed;
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(angle));

        matrices.pop();
    }
}
