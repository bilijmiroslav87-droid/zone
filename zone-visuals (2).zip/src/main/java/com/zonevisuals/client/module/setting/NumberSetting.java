package com.zonevisuals.client.module.setting;

public class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;

    public NumberSetting(String name, double min, double max, double defaultValue, double step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }
    public float getFloatValue() { return getValue().floatValue(); }
    public int getIntValue() { return getValue().intValue(); }
}
